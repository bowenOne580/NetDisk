#ifndef CONFIG_H
#define CONFIG_H
int port = 8880; //port name
char addrs[15] = "127.0.0.1"; //ip address
int blockLen = 131072; //buffer size
#endif